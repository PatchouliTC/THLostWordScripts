import logging
from airtest.core.settings import Settings as ST

def init_logging():
    # logger = logging.root
    # use 'airtest' as root logger name to prevent changing other modules' logger
    logger = logging.getLogger("airtest")
    try:
        logger.setLevel(ST.LOG_LEVEL)
    except:
        logger.setLevel(logging.DEBUG)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        fmt='[%(asctime)s][%(levelname)s]<%(name)s> %(message)s',
        datefmt='%I:%M:%S'
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)


init_logging()


def get_root_logger():
    return logging.getLogger('airtest')

def set_root_logger_level(level:int):
    logging.getLogger('airtest').setLevel(level)

def get_logger(name):
    logger = logging.getLogger(name)
    return logger
