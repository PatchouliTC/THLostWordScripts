"""
This package provide Windows Client Class.
"""
from .linux import Linux
