# -*- coding: utf-8 -*-
from airtest.utils.resolution import cocos_min_strategy
import logging
import os


class Settings(object):
    DEBUG = False
    LOG_DIR = None
    LOG_FILE = "log.txt"
    LOG_LEVEL=logging.DEBUG #设置日志显示级别，任何非logging定义的值均会导致默认使用DEBUG级别
    RESIZE_METHOD = staticmethod(cocos_min_strategy)
    CVSTRATEGY = ["surf", "tpl", "brisk"]  # 特征匹配可用方法: kaze/brisk/akaze/orb, contrib: sift/surf/brief
    KEYPOINT_MATCHING_PREDICTION = True
    THRESHOLD = 0.7  # 全局相似阈值，范围[0, 1]
    THRESHOLD_STRICT = 0.7  # [0, 1]
    OPDELAY = 0.1 #每次行为后的默认延迟时间，单位秒
    FIND_TIMEOUT = 20 #默认单次识别超时时间
    FIND_TIMEOUT_TMP = 3
    PROJECT_ROOT = os.environ.get("PROJECT_ROOT", "")  # for ``using`` other script
    SNAPSHOT_QUALITY = 10  # #截图质量范围[1-99]，详情见https://pillow.readthedocs.io/en/5.1.x/handbook/image-file-formats.html#jpeg
