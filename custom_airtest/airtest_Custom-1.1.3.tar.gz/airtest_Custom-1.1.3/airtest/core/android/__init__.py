"""
This package provide Android Device Class.
"""
from airtest.core.android.android import Android
