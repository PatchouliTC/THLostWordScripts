"""
This package provide IOS Device Class.
"""
from airtest.core.ios.ios import IOS
