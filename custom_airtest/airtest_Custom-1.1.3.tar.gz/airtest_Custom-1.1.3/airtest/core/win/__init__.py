"""
This package provide Windows Client Class.
"""
from .win import Windows
