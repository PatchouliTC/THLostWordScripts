#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Declaration：
    使用模板匹配比较两张图片的相似度和相似位置的相似度
"""


import cv2
from .utils import img_mat_rgb_2_gray

# B,G,R三通道心理学权重,用于彩色图模板匹配
weight = (0.114, 0.587, 0.299)

def cal_ccoeff_confidence(im_source, im_search):
    """
    对两张图片灰度化进行模板匹配，并返回匹配结果相似度最高的值.
    使用TM_CCOEFF_NORMED方法.
    :param im_source: 原始图像矩阵
    :param im_search: 匹配图像矩阵
    :return: 最大相似度
    """
    #灰度化
    im_source, im_search = img_mat_rgb_2_gray(im_source), img_mat_rgb_2_gray(im_search)
    #模板匹配
    res = cv2.matchTemplate(im_source, im_search, cv2.TM_CCOEFF_NORMED)
    #匹配结果中取最大值
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    confidence = max_val
    return confidence


def cal_rgb_confidence(img_src_rgb, img_sch_rgb):
    """
    对两张图片B,G,R三原色分别进行模板匹配，之后根据经典权重计算生成彩色图模板匹配相似度
    使用TM_CCOEFF_NORMED方法.
    :param img_src_rgb: 原始图像矩阵
    :param img_sch_rgb: 匹配图像矩阵
    :return: 最大相似度
    """
    #分割BGR三原色
    src_bgr, sch_bgr = cv2.split(img_src_rgb), cv2.split(img_sch_rgb)
    # 分别计算BGR三原色各自模板匹配的结果,存入bgr_confidence
    bgr_confidence = [0, 0, 0]
    for i in range(3):
        res_temp = cv2.matchTemplate(src_bgr[i], sch_bgr[i], cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res_temp)
        bgr_confidence[i] = max_val

    # 根据wight加权计算三色总计的相似度
    weighted_confidence = bgr_confidence[0] * weight[0] + bgr_confidence[1] * weight[1] + bgr_confidence[2] * weight[2]

    return weighted_confidence
